<?php
   require "connect.php";
   $query = "SELECT comment.id,comment.cmt_content,comment.cmt_datetime, post.title , user.username FROM comment INNER JOIN user ON user.id = comment.cmt_author
   INNER JOIN post ON post.id = comment.cmt_post";
   $data = mysqli_query($con,$query);
   class Comment{
       function Comment($id,$cmt_content,$cmt_author,$cmt_datetime,$post){
           $this->Id=$id;
           $this->Content=$cmt_content;
           $this->author =$cmt_author;
           $this->datetime =$cmt_datetime;
           $this->post = $post;
       }
   }
   $arraycomment = array();
   while($row = mysqli_fetch_assoc($data)){
    array_push($arraycomment , new Comment($row['id']
                                      ,$row['cmt_content']
                                      ,$row['username']
                                      ,$row['cmt_datetime']
                                      ,$row['title']));
   }
   echo json_encode($arraycomment);
?>