<?php
   require "connect.php";
   class Postwithcategory{
        function Postwithcategory($id,$title,$datetime,$thumbnail,$content,$category,$author,$categoryTitle){
            $this->id = $id;
            $this->title = $title;
            $this->datetime = $datetime;
            $this->thumbnail = $thumbnail;
            $this->content = $content;
            $this->category = $category;
            $this->author = $author;
            $this->categoryTitle = $categoryTitle;

        }
   }
   if(isset($_POST['category'])){
   $category = $_POST['category'];
   $query = "SELECT post.id, post.title, post.datetime, post.thumbnail, post.content, post.category, post.author, category.category_title FROM post INNER JOIN category ON post.category = category.id where FIND_IN_SET('$category', post.category)";
   }
   $arrayPostwithcategory = array();
   $data = mysqli_query($con,$query);
   while ($row = mysqli_fetch_assoc($data)) {
	array_push($arrayPostwithcategory, new Postwithcategory($row['id']
		,$row['title']
		,$row['datetime']
		,$row['thumbnail']
		,$row['content']
		,$row['category']
		,$row['author']
		,$row['category_title']));
   }
   echo json_encode($arrayPostwithcategory);
?>