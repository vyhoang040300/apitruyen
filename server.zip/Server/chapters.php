<?php

require "connect.php";
class Chapter{
	function Chapter($id, $title, $datetime, $content, $postId, $postTitle){

		$this->id = $id;
		$this->title = $title;
		$this->datetime = $datetime;
		$this->content = $content;
		$this->postId = $postId;
		$this->postTitle = $postTitle;

	}
}


if(isset($_POST['idpost'])){
$idpost = $_POST['idpost'];

$query = "SELECT chapter.id, chapter.chapter_title, chapter.chapter_datetime, chapter.chapter_content, chapter.post ,post.title
 FROM chapter INNER JOIN post ON chapter.post = post.id where chapter.post = $idpost";
}
$arrayChapter = array();
 


$data = mysqli_query($con,$query);
while ($row = mysqli_fetch_assoc($data)) {
	array_push($arrayChapter, new Chapter($row['id']
		,$row['chapter_title']
		,$row['chapter_datetime']
		,$row['chapter_content']
		,$row['post']
		,$row['title']));


}

echo json_encode($arrayChapter);

?>