<?php

require "connect.php";

$category_title = $_POST["category_title"];

$description = $_POST["description"];


$query = "SELECT * FROM `category` WHERE `category_title` = '$category_title'";
$result = mysqli_query($conn, $query);
if ($category_title == "" || $description == ""  ) {
	$status = "are missing!";
}
if (mysqli_num_rows($result) > 0) {
	$status = "exist";
}else{
	$query = "INSERT INTO `category` (category_title,description) VALUES ('$category_title', '$description');";
	if (mysqli_query($conn, $query)) {
		$status = "ok";
	}else{
		$status = "error";
	}
}
echo json_encode(array("response"=>$status));
mysqli_close($conn);


?>