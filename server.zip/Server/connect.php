<?php
  
  $hostname="localhost";
  $username="id11906674_admin";
  $password="admin";
  $databasename="id11906674_pro1121";
  $con = mysqli_connect($hostname,$username,$password,$databasename);
  mysqli_query($con,"SET NAMES 'utf8'");
  

?>