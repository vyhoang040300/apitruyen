<?php

require "connect.php";

$title = $_POST["title"];
$datetime = $_POST["datetime"];
$content = $_POST["content"];
$category = $_POST["category"];
$author = $_POST["author"]
$query = "SELECT * FROM `post` WHERE `title` = '$title'";
$result = mysqli_query($conn, $query);
if ($title == "" || $datetime == "" || $content == ""  $category == "" || $author == "" ) {
	$status = "are missing!";
}
if (mysqli_num_rows($result) > 0) {
	$status = "exist";
}else{
	$query = "INSERT INTO `user` (title, datetime,content,category,author) VALUES ('$title', '$datetime', '$content','$category', '$author');";
	if (mysqli_query($conn, $query)) {
		$status = "ok";
	}else{
		$status = "error";
	}
}
echo json_encode(array("response"=>$status));
mysqli_close($conn);


?>