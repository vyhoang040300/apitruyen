<?php

require "connect.php";

$query = "SELECT * FROM category";

$data = mysqli_query($con, $query);

class Category{
	function Category($id, $categorytitle, $slugcat, $description){

		$this->id = $id;
		$this->categorytitle = $categorytitle;
		$this->slugcat = $slugcat;
		$this->description = $description;
		
	
	}
}


$arrayChapter = array();
while ($row = mysqli_fetch_assoc($data)) {
	array_push($arrayChapter, new Category($row['id']
		,$row['category_title']
		,$row['slug_cat']
		,$row['description']));


}

echo json_encode($arrayChapter);

?>