<?php

require "connect.php";

$username = $_POST["username"];
$password = md5($_POST["password"]);
$email = $_POST["email"];

$query = "SELECT * FROM `user` WHERE `username` = '$username'";
$result = mysqli_query($conn, $query);
if ($username == "" || $password == "" || $email == "") {
	$status = "username, password, email are missing!";
}
if (mysqli_num_rows($result) > 0) {
	$status = "exist";
}else{
	$query = "INSERT INTO `user` (username, password, email) VALUES ('$username', '$password', '$email');";
	if (mysqli_query($conn, $query)) {
		$status = "ok";
	}else{
		$status = "error";
	}
}
echo json_encode(array("response"=>$status));
mysqli_close($conn);


?>