<?php 
require "connect.php";
$username = $_POST["username"];
$password = md5($_POST["password"]);

$query = "SELECT * FROM `user` WHERE `username` = '$username' AND `password` = '$password' AND `is_online` = 0";

$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) == 1) {
	$status = "Successfully";
	$query = "UPDATE `user` SET `is_online` = 1 WHERE `username` = '$username'";
	if ($conn->query($query) === TRUE) {
		$status = "Record updated successfully";
	} else {
		$status = "Error updating record: " . $conn->error;
	}
}else{
	$status = "Error";

}


echo json_encode(array("response"=>$status));
mysqli_close($conn);

?>