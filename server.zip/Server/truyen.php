<?php
require "connect.php";



class Truyen{
    function Truyen($id, $title, $datetime, $thumbnail, $content, $category, $author, $categoryTitle){

		$this->id = $id;
		$this->title = $title;
		$this->datetime = $datetime;
		$this->thumbnail = $thumbnail;
		$this->content = $content;
		$this->category = $category;
		$this->author = $author;
		$this->categoryTitle = $categoryTitle;


	}
}

$arrayTruyen = array();

if(isset($_POST['idtruyen'])){
    $idtruyen =$_POST['idtruyen'];
    $query ="SELECT post.id, post.title, post.datetime, post.thumbnail, post.content, post.category, post.author, category.category_title
FROM post INNER JOIN category ON post.category = category.id Where FIND_IN_SET('$idtruyen',post.id)";
}
$data = mysqli_query($con, $query);
while ($row = mysqli_fetch_assoc($data)) {
	array_push($arrayTruyen, new Truyen($row['id']
		,$row['title']
		,$row['datetime']
		,$row['thumbnail']
		,$row['content']
		,$row['category']
		,$row['author']
		,$row['category_title']));


}

echo json_encode($arrayTruyen);





?>