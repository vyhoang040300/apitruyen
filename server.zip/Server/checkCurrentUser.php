<?php 
require "connect.php";
$username = $_POST["username"];

$queryOnline = "SELECT `id`, `username`, `is_online` FROM `user` WHERE `username` = '$username' AND `is_online` = 1";

$checkOnline = mysqli_query($conn, $queryOnline);

if ($conn->query($queryOnline) === TRUE) {
	$status = "true";
}else{
	$status = "false";
}

echo json_encode(array("response"=>$status));
mysqli_close($conn);

?>